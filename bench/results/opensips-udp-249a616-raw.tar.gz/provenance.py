import json, hashlib, platform, subprocess, datetime
from pathlib import Path
r=Path('/tmp/madis-load-249a616')
m=json.loads((r/'source-manifest.json').read_text())
errors=[name for name,h in m['mko_sha256'].items() if hashlib.sha256((r/'source'/name).read_bytes()).hexdigest()!=h]
assert not errors, errors
m.update(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),system=platform.platform(),source_matches_manifest=True,build_flags='scripts/build-native.sh: GCC -std=c11 -O3 -DNDEBUG; matching Mako runtime; no sanitizers',test_driver_sha256=hashlib.sha256((r/'run.py').read_bytes()).hexdigest(),binary_sha256=hashlib.sha256((r/'madis').read_bytes()).hexdigest(),generated_c_sha256=hashlib.sha256((r/'source/main.c').read_bytes()).hexdigest(),compiler_binary_sha256=hashlib.sha256(Path('/tmp/madis-makori-caa7f36/target/release/makori').read_bytes()).hexdigest(),cpu_description=subprocess.check_output(['lscpu'],text=True),compiler_source_commit=subprocess.check_output(['git','-C','/tmp/madis-makori-249a616','rev-parse','HEAD'],text=True).strip(),production_process=subprocess.check_output(['ps','-C','madis','-o','pid,lstart,args'],text=True))
(r/'provenance.json').write_text(json.dumps(m,indent=2))
print('Verified',len(m['mko_sha256']),'source files; provenance recorded')
