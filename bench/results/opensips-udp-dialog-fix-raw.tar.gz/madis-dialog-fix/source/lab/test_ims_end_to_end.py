"""Opt-in two-subscriber IMS smoke test against a built Madis worker.

Run with:

    IMS_END_TO_END=1 MADIS_BIN=./main \
      python3 -m unittest lab.test_ims_end_to_end -v

    IMS_END_TO_END=1 IMS_END_TO_END_FORK=1 MADIS_BIN=./main \
      python3 -m unittest lab.test_ims_end_to_end.TwoSubscriberImsSmokeTests.test_ifc_fork_selects_branch_and_cancels_loser -v

    IMS_END_TO_END=1 IMS_END_TO_END_TIMEOUT=1 MADIS_BIN=./main \
      python3 -m unittest lab.test_ims_end_to_end.TwoSubscriberImsSmokeTests.test_unanswered_invite_times_out -v

    IMS_END_TO_END=1 IMS_END_TO_END_SESSION_TIMERS=1 MADIS_BIN=./main \
      python3 -m unittest lab.test_ims_end_to_end.TwoSubscriberImsSmokeTests.test_session_timer_min_se_and_forwarding -v

The test starts the lab HSS adapter as a real TCP peer, starts Madis on
loopback-only high ports, registers two users through Cx/AKA, and drives an
originating INVITE through provisional response, answer, ACK, and BYE.  When
the media sidecar is enabled for the test, it also checks SDP rewriting and
bidirectional RTP forwarding.  It is not part of the default CI job because
no worker binary or privileged SIP ports are assumed there.
"""

from __future__ import annotations

import base64
import hashlib
import http.client
import os
import re
import socket
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
import uuid
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
HSS_SCRIPT = ROOT / "lab" / "ims_hss.py"
MADIS_BIN = Path(os.environ.get("MADIS_BIN", str(ROOT / "main"))).expanduser().resolve()
RUN_E2E = os.environ.get("IMS_END_TO_END") == "1" and MADIS_BIN.is_file() and os.access(MADIS_BIN, os.X_OK)
RUN_E2E_TLS = RUN_E2E and os.environ.get("IMS_END_TO_END_TLS") == "1"
RUN_E2E_FORK = RUN_E2E and os.environ.get("IMS_END_TO_END_FORK") == "1"
RUN_E2E_TIMEOUT = RUN_E2E and os.environ.get("IMS_END_TO_END_TIMEOUT") == "1"
RUN_E2E_SESSION_TIMERS = RUN_E2E and os.environ.get("IMS_END_TO_END_SESSION_TIMERS") == "1"


def _free_port(kind: int) -> int:
    sock = socket.socket(socket.AF_INET, kind)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def _wait_tcp(host: str, port: int, timeout: float = 8.0) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.25):
                return
        except OSError as exc:
            last_error = exc
            time.sleep(0.05)
    raise AssertionError(f"TCP port {host}:{port} did not become ready: {last_error}")


def _wait_media(host: str, port: int, timeout: float = 8.0) -> None:
    deadline = time.monotonic() + timeout
    cookie = b"ims-e2e-media"
    packet = cookie + b" d7:command4:pinge"
    last_error: Exception | None = None
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        while time.monotonic() < deadline:
            try:
                sock.settimeout(min(0.25, max(0.05, deadline - time.monotonic())))
                sock.sendto(packet, (host, port))
                response, _ = sock.recvfrom(4096)
                if response.startswith(cookie + b" ") and b"6:result2:ok" in response:
                    return
            except OSError as exc:
                last_error = exc
            time.sleep(0.05)
    finally:
        sock.close()
    raise AssertionError(f"RTP sidecar port {host}:{port} did not become ready: {last_error}")


def _wait_diameter_tls(host: str, port: int, ca_file: Path, timeout: float = 8.0) -> None:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = True
    context.verify_mode = ssl.CERT_REQUIRED
    context.load_verify_locations(cafile=str(ca_file))
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.25) as raw:
                with context.wrap_socket(raw, server_hostname="localhost"):
                    return
        except (OSError, ssl.SSLError) as exc:
            last_error = exc
        time.sleep(0.05)
    raise AssertionError(f"TLS Diameter port {host}:{port} did not become ready: {last_error}")


def _wait_http(host: str, port: int, token: str = "", timeout: float = 8.0) -> None:
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            request = urllib.request.Request(f"http://{host}:{port}/healthz")
            if token:
                request.add_header("Authorization", f"Bearer {token}")
            with urllib.request.urlopen(request, timeout=0.25) as response:
                if response.status == 200:
                    return
        except urllib.error.HTTPError as exc:
            last_error = exc
            exc.close()
            time.sleep(0.05)
        except (OSError, urllib.error.URLError) as exc:
            last_error = exc
            time.sleep(0.05)
    raise AssertionError(f"HTTP port {host}:{port} did not become ready: {last_error}")


def _headers(message: str) -> dict[str, str]:
    head = message.split("\r\n\r\n", 1)[0]
    values: dict[str, str] = {}
    for line in head.split("\r\n")[1:]:
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        values[name.lower()] = value.strip()
    return values


def _status(message: str) -> int:
    fields = message.split("\r\n", 1)[0].split()
    return int(fields[1])


def _sdp_media_port(message: str) -> int:
    body = message.split("\r\n\r\n", 1)[1]
    for line in body.split("\r\n"):
        if line.startswith("m=audio "):
            fields = line.split()
            if len(fields) >= 2:
                return int(fields[1])
    raise AssertionError("SIP message did not contain an audio SDP media line")


def _digest_params(value: str) -> dict[str, str]:
    params: dict[str, str] = {}
    for match in re.finditer(r"([A-Za-z][A-Za-z0-9_-]*)\s*=\s*(?:\"([^\"]*)\"|([^,\s]+))", value):
        params[match.group(1).lower()] = match.group(2) if match.group(2) is not None else match.group(3)
    return params


def _header_line(headers: dict[str, str], name: str) -> str:
    return f"{name}: {headers[name.lower()]}\r\n"


def _header_lines(message: str, name: str) -> str:
    values = []
    for line in message.split("\r\n")[1:]:
        if ":" not in line:
            continue
        header_name, value = line.split(":", 1)
        if header_name.lower() == name.lower():
            values.append(value.strip())
    return "".join(f"{name}: {value}\r\n" for value in values)


class SipClient:
    def __init__(self) -> None:
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(("127.0.0.1", 0))
        self.socket.settimeout(2.0)
        self.address = self.socket.getsockname()

    def send(self, message: str, port: int) -> None:
        self.socket.sendto(message.encode("ascii"), ("127.0.0.1", port))

    def receive(self, predicate, timeout: float = 5.0) -> str:
        deadline = time.monotonic() + timeout
        seen: list[str] = []
        while time.monotonic() < deadline:
            self.socket.settimeout(max(0.1, deadline - time.monotonic()))
            try:
                raw, _ = self.socket.recvfrom(65535)
            except socket.timeout:
                break
            message = raw.decode("ascii", "replace")
            seen.append(" | ".join(message.split("\r\n")[:7]))
            if predicate(message):
                return message
        raise AssertionError(f"SIP message did not arrive; saw {seen}")

    def close(self) -> None:
        self.socket.close()


@unittest.skipUnless(RUN_E2E, "set IMS_END_TO_END=1 and provide an executable MADIS_BIN")
class TwoSubscriberImsSmokeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.hss_diameter_port = _free_port(socket.SOCK_STREAM)
        self.hss_http_port = _free_port(socket.SOCK_STREAM)
        self.sip_port = _free_port(socket.SOCK_DGRAM)
        self.admin_port = _free_port(socket.SOCK_STREAM)
        self.tls_port = _free_port(socket.SOCK_STREAM)
        self.wss_port = _free_port(socket.SOCK_STREAM)
        self.media_control_port = _free_port(socket.SOCK_DGRAM)
        self.media_min = 41000
        self.media_max = 41127
        self.alice = SipClient()
        self.bob = SipClient()
        self.fork_clients: list[SipClient] = []
        if RUN_E2E_FORK:
            self.fork_clients = [SipClient(), SipClient()]
        self.alice_media = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.alice_media.bind(("127.0.0.1", 0))
        self.alice_media.settimeout(2.0)
        self.bob_media = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.bob_media.bind(("127.0.0.1", 0))
        self.bob_media.settimeout(2.0)
        self.processes: list[subprocess.Popen] = []
        self.hss_process: subprocess.Popen | None = None
        self.tempdir = tempfile.TemporaryDirectory(prefix="madis-ims-e2e-")
        self.use_diameter_tls = RUN_E2E_TLS
        self.diameter_cert: Path | None = None
        self.diameter_key: Path | None = None
        # Subscriber authorization (iFC/associated URIs) flows only through the
        # HTTPS boundary, so the smoke always stands it up with ephemeral certs.
        self.subscriber_token = "ims-e2e-subscriber-token-1234"
        self.http_cert, self.http_key = self._generate_tls_material("hss-http")
        self.seed = Path(self.tempdir.name) / "subscribers.json"
        alice_profile = ""
        # Only the fork test may carry iFC targets; in FORK mode every test
        # shares this setUp, and an armed trigger would divert every INVITE.
        if RUN_E2E_FORK and self._testMethodName == "test_ifc_fork_selects_branch_and_cancels_loser":
            alice_profile = (
                ",\"service_profile\":{\"initial_filter_criteria\":["
                f"\"sip:fork-a@127.0.0.1:{self.fork_clients[0].address[1]}\","
                f"\"sip:fork-b@127.0.0.1:{self.fork_clients[1].address[1]}\"]}}"
            )
        self.seed.write_text(
            "{\"subscribers\":["
            "{\"public_identity\":\"sip:alice@example.com\",\"private_identity\":\"alice@example.com\",\"assigned_server_name\":\"sip:scscf.example.com\",\"xres_base64\":\"" + base64.b64encode(b"xres-alice").decode("ascii") + "\"" + alice_profile + "},"
            "{\"public_identity\":\"sip:bob@example.com\",\"private_identity\":\"bob@example.com\",\"assigned_server_name\":\"sip:scscf.example.com\",\"xres_base64\":\"" + base64.b64encode(b"xres-bob").decode("ascii") + "\"}"
            "]}",
        )
        if self.use_diameter_tls:
            self._generate_diameter_tls_material()
        try:
            self._start_hss()
            self._start_media()
            self._start_madis()
        except Exception:
            self.tearDown()
            raise

    def tearDown(self) -> None:
        self.alice.close()
        self.bob.close()
        for client in self.fork_clients:
            client.close()
        for media_socket in (
            getattr(self, "alice_media", None),
            getattr(self, "bob_media", None),
        ):
            if media_socket is not None:
                media_socket.close()
        for process in reversed(getattr(self, "processes", [])):
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3.0)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=3.0)
            if process.stdout is not None:
                output = process.stdout.read()
                if output:
                    bounded = output[-8192:]
                    sys.stderr.write("\n--- IMS smoke child log ---\n" + bounded)
                    debug_path = os.environ.get("IMS_E2E_DEBUG_LOG")
                    if debug_path:
                        with open(debug_path, "a", encoding="utf-8") as debug:
                            debug.write("\n--- IMS smoke child log ---\n" + bounded)
        if hasattr(self, "tempdir"):
            self.tempdir.cleanup()

    def _generate_tls_material(self, prefix: str) -> tuple[Path, Path]:
        openssl = shutil.which("openssl")
        if openssl is None:
            self.fail("openssl is required for ephemeral TLS material")
        cert = Path(self.tempdir.name) / f"{prefix}.crt"
        key = Path(self.tempdir.name) / f"{prefix}.key"
        try:
            subprocess.run(
                [
                    openssl,
                    "req",
                    "-x509",
                    "-newkey",
                    "rsa:2048",
                    "-nodes",
                    "-keyout",
                    str(key),
                    "-out",
                    str(cert),
                    "-days",
                    "1",
                    "-subj",
                    "/CN=localhost",
                    "-addext",
                    "subjectAltName=IP:127.0.0.1,DNS:localhost",
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )
        except (OSError, subprocess.CalledProcessError) as exc:
            self.fail(f"could not generate ephemeral TLS certificate: {exc}")
        return cert, key

    def _generate_diameter_tls_material(self) -> None:
        self.diameter_cert, self.diameter_key = self._generate_tls_material("hss")

    def _start_hss(self) -> None:
        command = [
            sys.executable,
            str(HSS_SCRIPT),
            "--seed-json",
            str(self.seed),
            "--diameter-host",
            "127.0.0.1",
            "--diameter-port",
            str(self.hss_diameter_port),
            "--http-host",
            "127.0.0.1",
            "--http-port",
            str(self.hss_http_port),
            "--http-cert",
            str(self.http_cert),
            "--http-key",
            str(self.http_key),
            "--http-token",
            self.subscriber_token,
        ]
        if self.use_diameter_tls:
            assert self.diameter_cert is not None
            assert self.diameter_key is not None
            command.extend(
                [
                    "--diameter-cert",
                    str(self.diameter_cert),
                    "--diameter-key",
                    str(self.diameter_key),
                ]
            )
        hss_env = os.environ.copy()
        process = subprocess.Popen(command, env=hss_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self.hss_process = process
        self.processes.append(process)
        if self.use_diameter_tls:
            assert self.diameter_cert is not None
            _wait_diameter_tls("127.0.0.1", self.hss_diameter_port, self.diameter_cert)
        else:
            _wait_tcp("127.0.0.1", self.hss_diameter_port)
        _wait_tcp("127.0.0.1", self.hss_http_port)

    @staticmethod
    def _stop_child(process: subprocess.Popen) -> None:
        if process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(timeout=3.0)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3.0)

    def _start_media(self) -> None:
        command = [
            sys.executable,
            str(ROOT / "media" / "rtp_module.py"),
            "--control-host",
            "127.0.0.1",
            "--control-port",
            str(self.media_control_port),
            "--media-bind",
            "127.0.0.1",
            "--media-ip",
            "127.0.0.1",
            "--media-min",
            str(self.media_min),
            "--media-max",
            str(self.media_max),
            "--max-sessions",
            "8",
            "--session-timeout",
            "30",
        ]
        process = subprocess.Popen(
            command,
            env=os.environ.copy(),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        self.processes.append(process)
        _wait_media("127.0.0.1", self.media_control_port)

    def _start_madis(self) -> None:
        env = os.environ.copy()
        for key in (
            "SIP_DB_URL",
            "SIP_DIAMETER_CA",
            "SIP_DIAMETER_CLIENT_CERT",
            "SIP_DIAMETER_CLIENT_KEY",
        ):
            env.pop(key, None)
        diameter_tls = "1" if self.use_diameter_tls else "0"
        diameter_allow_plaintext = "0" if self.use_diameter_tls else "1"
        diameter_ca = str(self.diameter_cert) if self.diameter_cert is not None else ""
        diameter_host = "localhost" if self.use_diameter_tls else "127.0.0.1"
        env.update(
            {
                "SIP_BIND_IP": "127.0.0.1",
                "SIP_IPV6": "0",
                "SIP_UDP_PORT": str(self.sip_port),
                "SIP_ADMIN_PORT": str(self.admin_port),
                "SIP_TLS_PORT": str(self.tls_port),
                "SIP_WSS_PORT": str(self.wss_port),
                "SIP_ADMIN_TOKEN": "ims-e2e-admin-token-1234",
                "SIP_REALM": "example.com",
                "SIP_NODE_ID": "ims-e2e-node",
                "SIP_NODE_ADDR": "127.0.0.1",
            "SIP_DIAMETER_HOST": diameter_host,
                "SIP_DIAMETER_PORT": str(self.hss_diameter_port),
            "SIP_DIAMETER_TLS": diameter_tls,
            "SIP_DIAMETER_ALLOW_PLAINTEXT": diameter_allow_plaintext,
            "SIP_DIAMETER_CA": diameter_ca,
                "SIP_DIAMETER_ORIGIN_HOST": "scscf.lab.local",
                "SIP_DIAMETER_ORIGIN_REALM": "example.com",
                "SIP_DIAMETER_DEST_REALM": "example.com",
                "SIP_RTPENGINE_ENABLED": "1",
                "SIP_RTPENGINE_HOST": "127.0.0.1",
                "SIP_RTPENGINE_PORT": str(self.media_control_port),
                "SIP_RTPENGINE_NODES": f"127.0.0.1:{self.media_control_port}",
                "SIP_RTPENGINE_PROFILE": "plain",
                "SIP_IMS_CX": "1",
                "SIP_IMS_AKA": "1",
                "SIP_IMS_AKA_SCHEME": "Digest-AKAv1-MD5",
                "SIP_IMS_ROLE": "scscf",
                "SIP_IMS_VISITED_NETWORK": "example.com",
                "SIP_IMS_SERVER_NAME": "sip:scscf.example.com",
                "SIP_IMS_DEST_HOST": "hss.lab.local",
                "SIP_IMS_SESSION": "1",
                "SIP_IMS_SUBSCRIBER_URL": f"https://localhost:{self.hss_http_port}/ims/authorize",
                "SIP_IMS_SUBSCRIBER_TOKEN": self.subscriber_token,
                "SIP_IMS_SUBSCRIBER_CA": str(self.http_cert),
            }
        )
        if RUN_E2E_TIMEOUT:
            env["SIP_T1_MS"] = "100"
            env["SIP_TIMER_C_MS"] = "6400"
        if RUN_E2E_SESSION_TIMERS:
            env["SIP_IMS_SESSION_TIMERS"] = "1"
            env["SIP_IMS_SESSION_MIN_SE"] = "90"
            env["SIP_IMS_SESSION_MAX_SE"] = "3600"
        if self._testMethodName == "test_ifc_fork_selects_branch_and_cancels_loser":
            env["SIP_IMS_3PREG"] = "1"
        process = subprocess.Popen([str(MADIS_BIN)], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self.processes.append(process)
        _wait_http("127.0.0.1", self.admin_port, "ims-e2e-admin-token-1234")

    def _register(self, client: SipClient, user: str, xres: bytes) -> str:
        call_id = f"register-{user}-{uuid.uuid4().hex[:12]}"
        from_header = f"<sip:{user}@example.com>;tag={user}-register"
        contact = f"<sip:{user}@127.0.0.1:{client.address[1]}>"

        def make_register(cseq: int, branch: str, authorization: str = "") -> str:
            extra = f"Authorization: {authorization}\r\n" if authorization else ""
            return (
                "REGISTER sip:example.com SIP/2.0\r\n"
                f"Via: SIP/2.0/UDP 127.0.0.1:{client.address[1]};branch={branch}\r\n"
                "Max-Forwards: 70\r\n"
                f"From: {from_header}\r\n"
                f"To: <sip:{user}@example.com>\r\n"
                f"Call-ID: {call_id}\r\n"
                f"CSeq: {cseq} REGISTER\r\n"
                f"Contact: {contact}\r\n"
                "Expires: 300\r\n"
                f"{extra}Content-Length: 0\r\n\r\n"
            )

        client.send(make_register(1, "z9hG4bK-" + uuid.uuid4().hex), self.sip_port)
        challenge = client.receive(lambda message: _status(message) in (401, 407))
        self.assertEqual(_status(challenge), 401)
        auth_header = _headers(challenge).get("www-authenticate", "")
        params = _digest_params(auth_header)
        self.assertEqual(params.get("algorithm", "").lower(), "akav1-md5")
        self.assertEqual(params.get("qop"), "auth")
        uri = "sip:example.com"
        cnonce = "ims-e2e-cnonce"
        nc = "00000001"
        ha1 = hashlib.md5(f"{user}@example.com:example.com:{xres.decode('ascii')}".encode("ascii")).hexdigest()
        ha2 = hashlib.md5(f"REGISTER:{uri}".encode("ascii")).hexdigest()
        response = hashlib.md5(f"{ha1}:{params['nonce']}:{nc}:{cnonce}:auth:{ha2}".encode("ascii")).hexdigest()
        authorization = (
            f'Digest username="{user}@example.com", realm="example.com", nonce="{params["nonce"]}", '
            f'uri="{uri}", response="{response}", algorithm=AKAv1-MD5, qop=auth, nc={nc}, cnonce="{cnonce}"'
        )
        auth_message = make_register(2, "z9hG4bK-" + uuid.uuid4().hex, authorization)
        client.send(auth_message, self.sip_port)
        accepted = client.receive(lambda message: _status(message) == 200)
        self.assertEqual(_status(accepted), 200)
        return auth_message

    def test_hss_unavailable_fails_closed(self) -> None:
        """A live worker must reject a REGISTER when its Cx peer disappears."""
        assert self.hss_process is not None
        self._stop_child(self.hss_process)
        message = (
            "REGISTER sip:example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-hss-down\r\n"
            "Max-Forwards: 70\r\n"
            "From: <sip:alice@example.com>;tag=hss-down\r\n"
            "To: <sip:alice@example.com>\r\n"
            "Call-ID: hss-down@example.com\r\n"
            "CSeq: 1 REGISTER\r\n"
            f"Contact: <sip:alice@127.0.0.1:{self.alice.address[1]}>\r\n"
            "Expires: 300\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(message, self.sip_port)
        rejected = self.alice.receive(lambda item: _status(item) in (500, 503))
        self.assertEqual(_status(rejected), 503)

    def test_register_retransmission_replays_response(self) -> None:
        auth_message = self._register(self.alice, "alice", b"xres-alice")
        auth_headers = _headers(auth_message)
        self.alice.send(auth_message, self.sip_port)
        replay = self.alice.receive(
            lambda message: _status(message) == 200
            and _headers(message).get("cseq", "").startswith("2 REGISTER")
        )
        replay_headers = _headers(replay)
        self.assertEqual(replay_headers.get("call-id"), auth_headers.get("call-id"))
        self.assertEqual(replay_headers.get("cseq"), "2 REGISTER")

    @unittest.skipUnless(RUN_E2E_TIMEOUT, "set IMS_END_TO_END_TIMEOUT=1 with IMS_END_TO_END=1")
    def test_unanswered_invite_times_out(self) -> None:
        self._register(self.alice, "alice", b"xres-alice")
        self._register(self.bob, "bob", b"xres-bob")
        call_id, _, _, _ = self._invite()
        self.bob.receive(lambda message: message.startswith("INVITE "))
        timeout = self.alice.receive(
            lambda message: _status(message) == 408 and _headers(message).get("cseq") == "2 INVITE",
            timeout=10.0,
        )
        self.assertEqual(_headers(timeout).get("call-id"), call_id)

    @unittest.skipUnless(
        RUN_E2E_SESSION_TIMERS,
        "set IMS_END_TO_END_SESSION_TIMERS=1 with IMS_END_TO_END=1",
    )
    def test_session_timer_min_se_and_forwarding(self) -> None:
        self._register(self.alice, "alice", b"xres-alice")
        self._register(self.bob, "bob", b"xres-bob")

        too_small_id, _, _, _ = self._invite(
            "Session-Expires: 60;refresher=uac\r\n"
        )
        rejected = self.alice.receive(
            lambda message: _status(message) == 422
            and _headers(message).get("cseq") == "2 INVITE"
        )
        rejected_headers = _headers(rejected)
        self.assertEqual(rejected_headers.get("call-id"), too_small_id)
        self.assertEqual(rejected_headers.get("min-se"), "90")

        call_id, _, _, _ = self._invite(
            "Session-Expires: 90;refresher=uac\r\n"
        )
        forwarded = self.bob.receive(lambda message: message.startswith("INVITE "))
        forwarded_headers = _headers(forwarded)
        self.assertEqual(forwarded_headers.get("session-expires"), "90;refresher=uac")
        busy = (
            "SIP/2.0 486 Busy Here\r\n"
            + _header_lines(forwarded, "Via")
            + _header_line(forwarded_headers, "from")
            + _header_line(forwarded_headers, "to")
            + _header_line(forwarded_headers, "call-id")
            + _header_line(forwarded_headers, "cseq")
            + "Content-Length: 0\r\n\r\n"
        )
        self.bob.send(busy, self.sip_port)
        self.alice.receive(
            lambda message: _status(message) == 486
            and _headers(message).get("call-id") == call_id
        )
        self.bob.receive(lambda message: message.startswith("ACK "))

    def _invite(self, extra_headers: str = "") -> tuple[str, str, str, str]:
        call_id = "call-" + uuid.uuid4().hex[:12]
        alice_tag = "alice-call"
        branch = "z9hG4bK-" + uuid.uuid4().hex
        sdp = (
            "v=0\r\n"
            "o=- 1 1 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.alice_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        message = (
            "INVITE sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch={branch}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            "To: <sip:bob@example.com>\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 1 INVITE\r\n"
            f"Contact: <sip:alice@127.0.0.1:{self.alice.address[1]}>\r\n"
            + extra_headers
            + "Content-Type: application/sdp\r\n"
            f"Content-Length: {len(sdp)}\r\n\r\n{sdp}"
    )
        self.alice.send(message, self.sip_port)
        challenge = self.alice.receive(lambda item: _status(item) == 401)
        challenge_params = _digest_params(_headers(challenge).get("www-authenticate", ""))
        self.assertEqual(challenge_params.get("qop"), "auth")
        cnonce = "ims-e2e-invite-cnonce"
        nc = "00000001"
        ha1 = hashlib.md5(
            f"alice@example.com:example.com:xres-alice".encode("ascii")
        ).hexdigest()
        ha2 = hashlib.md5(
            b"INVITE:sip:bob@example.com"
        ).hexdigest()
        response = hashlib.md5(
            f"{ha1}:{challenge_params['nonce']}:{nc}:{cnonce}:auth:{ha2}".encode("ascii")
        ).hexdigest()
        authorization = (
            'Digest username="alice@example.com", realm="example.com", '
            f'nonce="{challenge_params["nonce"]}", uri="sip:bob@example.com", '
            f'response="{response}", algorithm=AKAv1-MD5, qop=auth, nc={nc}, '
            f'cnonce="{cnonce}"'
        )
        auth_message = message.replace(
            f"branch={branch}", f"branch={branch}-authenticated"
        ).replace(
            "CSeq: 1 INVITE\r\n",
            "CSeq: 2 INVITE\r\n"
        ).replace(
            "Content-Type: application/sdp\r\n",
            f"Authorization: {authorization}\r\nContent-Type: application/sdp\r\n"
        )
        self.alice.send(auth_message, self.sip_port)
        return call_id, alice_tag, branch, sdp

    @unittest.skipUnless(RUN_E2E_FORK, "set IMS_END_TO_END_FORK=1 with IMS_END_TO_END=1")
    def test_ifc_fork_selects_branch_and_cancels_loser(self) -> None:
        fork_a, fork_b = self.fork_clients
        self._register(self.alice, "alice", b"xres-alice")
        # Third-party REGISTER: the S-CSCF originates one REGISTER per iFC AS
        # target after the 200; each AS accepts it with a local 200 OK.
        for fork_client in (fork_a, fork_b):
            third_party = fork_client.receive(
                lambda message: message.startswith("REGISTER ") and "z9hG4bK-3preg-" in message
            )
            third_party_headers = _headers(third_party)
            self.assertEqual(third_party_headers.get("to"), "<sip:alice@example.com>")
            self.assertEqual(third_party_headers.get("expires"), "300")
            fork_client.send(
                "SIP/2.0 200 OK\r\n"
                + _header_lines(third_party, "Via")
                + _header_line(third_party_headers, "from")
                + _header_line(third_party_headers, "to")
                + _header_line(third_party_headers, "call-id")
                + _header_line(third_party_headers, "cseq")
                + "Content-Length: 0\r\n\r\n",
                self.sip_port,
            )
        self._register(self.bob, "bob", b"xres-bob")
        call_id, alice_tag, _, _ = self._invite()
        # Loopback ingress is IP-authenticated by the worker, so the initial
        # (CSeq 1) INVITE is forked as well as the authenticated (CSeq 2) one.
        # The session under test is the authenticated leg.
        fork_a_invite = fork_a.receive(lambda message: message.startswith("INVITE ") and "CSeq: 2 INVITE" in message)
        fork_b_invite = fork_b.receive(lambda message: message.startswith("INVITE ") and "CSeq: 2 INVITE" in message)
        fork_a_headers = _headers(fork_a_invite)
        fork_b_headers = _headers(fork_b_invite)
        fork_a_tag = "fork-a-call"
        fork_b_tag = "fork-b-call"

        fork_a_provisional = (
            "SIP/2.0 183 Session Progress\r\n"
            + _header_lines(fork_a_invite, "Via")
            + _header_line(fork_a_headers, "from")
            + f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            + _header_line(fork_a_headers, "call-id")
            + _header_line(fork_a_headers, "cseq")
            + "Require: 100rel\r\n"
            + "RSeq: 1\r\n"
            + "Content-Length: 0\r\n\r\n"
        )
        fork_b_ringing = (
            "SIP/2.0 180 Ringing\r\n"
            + _header_lines(fork_b_invite, "Via")
            + _header_line(fork_b_headers, "from")
            + f"To: <sip:bob@example.com>;tag={fork_b_tag}\r\n"
            + _header_line(fork_b_headers, "call-id")
            + _header_line(fork_b_headers, "cseq")
            + "Content-Length: 0\r\n\r\n"
        )
        fork_a.send(fork_a_provisional, self.sip_port)
        fork_b.send(fork_b_ringing, self.sip_port)

        provisional = self.alice.receive(lambda message: _status(message) == 183)
        ringing = self.alice.receive(lambda message: _status(message) == 180)
        self.assertEqual(_headers(provisional).get("to", "").split("tag=", 1)[-1], fork_a_tag)
        self.assertEqual(_headers(ringing).get("to", "").split("tag=", 1)[-1], fork_b_tag)

        prack = (
            "PRACK sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-prack-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            + _header_line(fork_a_headers, "from")
            + f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            + _header_line(fork_a_headers, "call-id")
            + "CSeq: 3 PRACK\r\n"
            + "RAck: 1 2 INVITE\r\n"
            + "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(prack, self.sip_port)
        forwarded_prack = fork_a.receive(lambda message: message.startswith("PRACK "))
        self.assertEqual(_headers(forwarded_prack).get("to", "").split("tag=", 1)[-1], fork_a_tag)
        prack_headers = _headers(forwarded_prack)
        fork_a.send(
            "SIP/2.0 200 OK\r\n"
            + _header_lines(forwarded_prack, "Via")
            + _header_line(prack_headers, "from")
            + f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            + _header_line(prack_headers, "call-id")
            + _header_line(prack_headers, "cseq")
            + "Content-Length: 0\r\n\r\n",
            self.sip_port,
        )
        self.alice.receive(lambda message: _status(message) == 200 and "PRACK" in message)

        answer_sdp = (
            "v=0\r\n"
            "o=- 2 2 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.bob_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        fork_a_ok = (
            "SIP/2.0 200 OK\r\n"
            + _header_lines(fork_a_invite, "Via")
            + _header_line(fork_a_headers, "from")
            + f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            + _header_line(fork_a_headers, "call-id")
            + _header_line(fork_a_headers, "cseq")
            + f"Contact: <sip:fork-a@127.0.0.1:{fork_a.address[1]}>\r\n"
            + "Content-Type: application/sdp\r\n"
            + f"Content-Length: {len(answer_sdp.encode('ascii'))}\r\n\r\n{answer_sdp}"
        )
        fork_a.send(fork_a_ok, self.sip_port)
        accepted = self.alice.receive(
            lambda message: _status(message) == 200 and _headers(message).get("cseq") == "2 INVITE"
        )
        self.assertEqual(_headers(accepted).get("to", "").split("tag=", 1)[-1], fork_a_tag)

        forwarded_cancel = fork_b.receive(lambda message: message.startswith("CANCEL ") and "CSeq: 2 CANCEL" in message)
        cancel_headers = _headers(forwarded_cancel)
        fork_b.send(
            "SIP/2.0 200 OK\r\n"
            + _header_lines(forwarded_cancel, "Via")
            + _header_line(cancel_headers, "from")
            + _header_line(cancel_headers, "to")
            + _header_line(cancel_headers, "call-id")
            + _header_line(cancel_headers, "cseq")
            + "Content-Length: 0\r\n\r\n",
            self.sip_port,
        )
        self.assertEqual(cancel_headers.get("cseq"), "2 CANCEL")

        ack = (
            "ACK sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-ack-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 1 ACK\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(ack, self.sip_port)
        fork_a.receive(lambda message: message.startswith("ACK "))

        bye = (
            "BYE sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-bye-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={fork_a_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 3 BYE\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(bye, self.sip_port)
        forwarded_bye = fork_a.receive(lambda message: message.startswith("BYE "))
        bye_headers = _headers(forwarded_bye)
        fork_a.send(
            "SIP/2.0 200 OK\r\n"
            + _header_lines(forwarded_bye, "Via")
            + _header_line(bye_headers, "from")
            + _header_line(bye_headers, "to")
            + _header_line(bye_headers, "call-id")
            + _header_line(bye_headers, "cseq")
            + "Content-Length: 0\r\n\r\n",
            self.sip_port,
        )
        self.alice.receive(lambda message: _status(message) == 200 and "BYE" in message)

    def test_two_subscribers_cancel_call(self) -> None:
        self._register(self.alice, "alice", b"xres-alice")
        self._register(self.bob, "bob", b"xres-bob")
        call_id, _, _, _ = self._invite()
        invite = self.bob.receive(lambda message: message.startswith("INVITE "))
        invite_headers = _headers(invite)
        cancel = (
            "CANCEL sip:bob@example.com SIP/2.0\r\n"
            + _header_line(invite_headers, "via")
            + "Max-Forwards: 70\r\n"
            + f"{_header_line(invite_headers, 'from')}"
            + "To: <sip:bob@example.com>\r\n"
            + f"{_header_line(invite_headers, 'call-id')}"
            + "CSeq: 2 CANCEL\r\n"
            + "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(cancel, self.sip_port)
        cancelled = self.alice.receive(
            lambda message: _status(message) == 200
            and _headers(message).get("cseq", "").startswith("2 CANCEL")
        )
        self.assertEqual(_status(cancelled), 200)
        forwarded_cancel = self.bob.receive(
            lambda message: message.startswith("CANCEL ")
        )
        self.assertEqual(_headers(forwarded_cancel).get("cseq"), "2 CANCEL")
        terminated = (
            "SIP/2.0 487 Request Terminated\r\n"
            + _header_lines(invite, "Via")
            + f"{_header_line(invite_headers, 'from')}"
            + "To: <sip:bob@example.com>;tag=bob-cancel\r\n"
            + f"{_header_line(invite_headers, 'call-id')}"
            + f"{_header_line(invite_headers, 'cseq')}"
            + "Content-Length: 0\r\n\r\n"
        )
        self.bob.send(terminated, self.sip_port)
        # Authenticated INVITE uses CSeq 2 on the wire; UAS may echo the
        # pre-auth or post-auth sequence depending on which INVITE it answered.
        rejected = self.alice.receive(
            lambda message: _status(message) == 487
            and "INVITE" in _headers(message).get("cseq", "").upper()
        )
        self.assertEqual(_status(rejected), 487)

    def test_two_subscribers_register_call_and_clear(self) -> None:
        self._register(self.alice, "alice", b"xres-alice")
        self._register(self.bob, "bob", b"xres-bob")
        call_id, alice_tag, _, _ = self._invite()
        invite = self.bob.receive(lambda message: message.startswith("INVITE "))
        invite_headers = _headers(invite)
        offer_media_port = _sdp_media_port(invite)
        self.assertNotEqual(offer_media_port, self.alice_media.getsockname()[1])
        bob_tag = "bob-call"
        # Unreliable 180 keeps the smoke focused on REGISTER/INVITE/ACK/BYE.
        # Reliable 183/PRACK is covered by unit tests (ims_roles_test).
        ringing = (
            "SIP/2.0 180 Ringing\r\n"
            + _header_lines(invite, "Via")
            + f"{_header_line(invite_headers, 'from')}"
            + f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            + f"{_header_line(invite_headers, 'call-id')}"
            + f"{_header_line(invite_headers, 'cseq')}"
            + "Content-Length: 0\r\n\r\n"
        )
        self.bob.send(ringing, self.sip_port)
        self.alice.receive(lambda message: _status(message) == 180)
        answer_sdp = (
            "v=0\r\n"
            "o=- 2 2 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.bob_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        ok = (
        "SIP/2.0 200 OK\r\n"
        + _header_lines(invite, "Via")
        + f"{_header_line(invite_headers, 'from')}"
        + f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
        + f"{_header_line(invite_headers, 'call-id')}"
        + f"{_header_line(invite_headers, 'cseq')}"
        + f"Contact: <sip:bob@127.0.0.1:{self.bob.address[1]}>\r\n"
        + "Content-Type: application/sdp\r\n"
        + f"Content-Length: {len(answer_sdp)}\r\n\r\n{answer_sdp}"
        )
        self.bob.send(ok, self.sip_port)
        accepted = self.alice.receive(lambda message: _status(message) == 200)
        answer_media_port = _sdp_media_port(accepted)
        self.assertNotEqual(answer_media_port, self.bob_media.getsockname()[1])
        alice_packet = b"\x80\x00\x00\x01\x00\x00\x00\x01\x12\x34\x56\x78alice-media"
        self.alice_media.sendto(alice_packet, ("127.0.0.1", offer_media_port))
        forwarded_to_bob, _ = self.bob_media.recvfrom(4096)
        self.assertEqual(forwarded_to_bob, alice_packet)
        bob_packet = b"\x80\x00\x00\x02\x00\x00\x00\x02\x87\x65\x43\x21bob-media"
        self.bob_media.sendto(bob_packet, ("127.0.0.1", answer_media_port))
        forwarded_to_alice, _ = self.alice_media.recvfrom(4096)
        self.assertEqual(forwarded_to_alice, bob_packet)
        accepted_headers = _headers(accepted)
        ack = (
            "ACK sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 1 ACK\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(ack, self.sip_port)
        self.bob.receive(lambda message: message.startswith("ACK "))
        update_sdp = (
            "v=0\r\n"
            "o=- 3 3 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.alice_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        update = (
            "UPDATE sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 3 UPDATE\r\n"
            f"Contact: <sip:alice@127.0.0.1:{self.alice.address[1]}>\r\n"
            "Content-Type: application/sdp\r\n"
            f"Content-Length: {len(update_sdp.encode('ascii'))}\r\n\r\n"
            + update_sdp
        )
        self.alice.send(update, self.sip_port)
        forwarded_update = self.bob.receive(lambda message: message.startswith("UPDATE "))
        self.assertNotEqual(_sdp_media_port(forwarded_update), self.alice_media.getsockname()[1])
        update_headers = _headers(forwarded_update)
        update_answer_sdp = (
            "v=0\r\n"
            "o=- 4 4 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.bob_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        update_ok = (
            "SIP/2.0 200 OK\r\n"
            + _header_lines(forwarded_update, "Via")
            + f"{_header_line(update_headers, 'from')}"
            + f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            + f"{_header_line(update_headers, 'call-id')}"
            + f"{_header_line(update_headers, 'cseq')}"
            + "Content-Type: application/sdp\r\n"
            + f"Content-Length: {len(update_answer_sdp.encode('ascii'))}\r\n\r\n"
            + update_answer_sdp
        )
        self.bob.send(update_ok, self.sip_port)
        updated = self.alice.receive(
            lambda message: _status(message) == 200 and "UPDATE" in message
        )
        self.assertNotEqual(_sdp_media_port(updated), self.bob_media.getsockname()[1])
        reinvite_sdp = (
            "v=0\r\n"
            "o=- 5 5 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.alice_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        reinvite = (
            "INVITE sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 4 INVITE\r\n"
            f"Contact: <sip:alice@127.0.0.1:{self.alice.address[1]}>\r\n"
            "Content-Type: application/sdp\r\n"
            f"Content-Length: {len(reinvite_sdp.encode('ascii'))}\r\n\r\n"
            + reinvite_sdp
        )
        self.alice.send(reinvite, self.sip_port)
        forwarded_reinvite = self.bob.receive(
            lambda message: message.startswith("INVITE ")
        )
        self.assertNotEqual(
            _sdp_media_port(forwarded_reinvite), self.alice_media.getsockname()[1]
        )
        reinvite_headers = _headers(forwarded_reinvite)
        reinvite_answer_sdp = (
            "v=0\r\n"
            "o=- 6 6 IN IP4 127.0.0.1\r\n"
            "s=-\r\n"
            "c=IN IP4 127.0.0.1\r\n"
            "t=0 0\r\n"
            f"m=audio {self.bob_media.getsockname()[1]} RTP/AVP 0\r\n"
        )
        reinvite_ok = (
            "SIP/2.0 200 OK\r\n"
            + _header_lines(forwarded_reinvite, "Via")
            + f"{_header_line(reinvite_headers, 'from')}"
            + f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            + f"{_header_line(reinvite_headers, 'call-id')}"
            + f"{_header_line(reinvite_headers, 'cseq')}"
            + "Content-Type: application/sdp\r\n"
            + f"Content-Length: {len(reinvite_answer_sdp.encode('ascii'))}\r\n\r\n"
            + reinvite_answer_sdp
        )
        self.bob.send(reinvite_ok, self.sip_port)
        reinvite_accepted = self.alice.receive(
            lambda message: _status(message) == 200
            and _headers(message).get("cseq", "").startswith("4 INVITE")
        )
        self.assertNotEqual(
            _sdp_media_port(reinvite_accepted), self.bob_media.getsockname()[1]
        )
        reinvite_ack = (
            "ACK sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 4 ACK\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(reinvite_ack, self.sip_port)
        self.bob.receive(
            lambda message: message.startswith("ACK ")
            and _headers(message).get("cseq") == "4 ACK"
        )
        bye = (
            "BYE sip:bob@example.com SIP/2.0\r\n"
            f"Via: SIP/2.0/UDP 127.0.0.1:{self.alice.address[1]};branch=z9hG4bK-{uuid.uuid4().hex}\r\n"
            "Max-Forwards: 70\r\n"
            f"From: <sip:alice@example.com>;tag={alice_tag}\r\n"
            f"To: <sip:bob@example.com>;tag={bob_tag}\r\n"
            f"Call-ID: {call_id}\r\n"
            "CSeq: 5 BYE\r\n"
            "Content-Length: 0\r\n\r\n"
        )
        self.alice.send(bye, self.sip_port)
        bye_request = self.bob.receive(lambda message: message.startswith("BYE "))
        bye_headers = _headers(bye_request)
        bye_ok = (
            "SIP/2.0 200 OK\r\n"
            + _header_lines(bye_request, "Via")
            + f"{_header_line(bye_headers, 'from')}"
            + f"{_header_line(bye_headers, 'to')}"
            + f"{_header_line(bye_headers, 'call-id')}"
            + f"{_header_line(bye_headers, 'cseq')}"
            + "Content-Length: 0\r\n\r\n"
        )
        self.bob.send(bye_ok, self.sip_port)
        # BYE CSeq advances after authenticated INVITE/UPDATE/re-INVITE (e.g. 5 BYE).
        self.alice.receive(
            lambda message: _status(message) == 200
            and "BYE" in _headers(message).get("cseq", "").upper()
        )


if __name__ == "__main__":
    unittest.main()
